document.addEventListener('DOMContentLoaded', function() {
    const alertasContainer = document.getElementById('alertas-container');

    // Datos de ejemplo (normalmente vendrían de un archivo JSON o una API)
    // Puedes modificar estas alertas o añadir más directamente aquí
    const datosAlertas = [
      {
        "id": "msg001",
        "fecha": "2025-05-06 10:00:00",
        "fuente": "Firewall Corporativo",
        "severidad": "Alta",
        "titulo": "Intento de Acceso No Autorizado",
        "descripcion": "Detectado intento de acceso no autorizado desde IP 192.168.1.100 al servidor DB.",
        "recomendacion": "Verificar IP. Bloquear si es sospechosa. Revisar logs."
      },
      {
        "id": "msg002",
        "fecha": "2025-05-06 11:30:00",
        "fuente": "Antivirus Endpoint",
        "severidad": "Media",
        "titulo": "Software Malicioso Detectado",
        "descripcion": "Archivo 'invoice.exe' malicioso en 'USUARIO-PC05', puesto en cuarentena.",
        "recomendacion": "Confirmar que el usuario no lo descargó. Escaneo completo."
      },
      {
        "id": "msg003",
        "fecha": "2025-05-06 14:15:00",
        "fuente": "IA Monitoreo de Red",
        "severidad": "Informacional",
        "titulo": "Nuevo Dispositivo en Red",
        "descripcion": "Nuevo dispositivo con MAC XX:XX:XX:XX:XX:XX conectado a WiFi de invitados.",
        "recomendacion": "Monitorear actividad si no es esperado. Verificar política."
      },
      {
        "id": "msg004",
        "fecha": "2025-05-07 09:00:00",
        "fuente": "Detección Phishing Email",
        "severidad": "Alta",
        "titulo": "Correo Phishing Recibido",
        "descripcion": "Usuario 'laev@example.com' recibió email sospechoso con enlace a 'http://sitiofalso-banco.com'.",
        "recomendacion": "No hacer clic. Eliminar correo. Reforzar capacitación."
      }
      // Puedes añadir más objetos de alerta aquí, siguiendo el mismo formato.
    ];

    if (!alertasContainer) {
        console.error('El contenedor de alertas no fue encontrado en el HTML.');
        return;
    }

    if (datosAlertas.length === 0) {
        alertasContainer.innerHTML = '<p>No hay alertas para mostrar en este momento.</p>';
        return;
    }

    let htmlAlertas = '';
    datosAlertas.forEach(alerta => {
        htmlAlertas += `
            <div class="alerta alerta-severidad-${alerta.severidad}">
                <h2>${alerta.titulo}</h2>
                <div class="meta">
                    <p><strong>ID:</strong> ${alerta.id}</p>
                    <p><strong>Fecha:</strong> ${alerta.fecha}</p>
                    <p><strong>Fuente:</strong> ${alerta.fuente}</p>
                    <p><strong>Severidad:</strong> ${alerta.severidad}</p>
                </div>
                <p><strong>Descripción:</strong> ${alerta.descripcion}</p>
                <p><strong>Recomendación:</strong> ${alerta.recomendacion}</p>
            </div>
        `;
    });

    alertasContainer.innerHTML = htmlAlertas;
});